#include<stdio.h>
#include<math.h>

int main(){
	
	printf("\nScreen-to-body Ratio Calculator");
	printf("\n(by Alvin Zahran M.)");
	printf("\n\n=========================================================");
	
	double screenRatioLength;
	double screenRatioWidth;
	double deviceHeight;
	double deviceWidth;
	double screenSize;
	double screenRatio;
	double screenSizemm;
	double stbr;
	double stbrPercent;
	
	printf("\n\nEnter Aspect Ratio (for example: for 16:9, enter 16 9)!\n>   ");
	scanf("%lf %lf", &screenRatioLength, &screenRatioWidth);
	
	printf("\nEnter device length (in mm)!\n>   ");
	scanf("%lf", &deviceHeight);
	
	printf("\nEnter device width (in mm)!\n>   ");
	scanf("%lf", &deviceWidth);
	
	printf("\nEnter screen size (in inches)!\n>   ");
	scanf("%lf", &screenSize);
	
	screenRatio = screenRatioLength / screenRatioWidth;
	screenSizemm = screenSize * 25.4;
	
	stbr = (screenRatio*(pow(screenSizemm,2)))/(((pow(screenRatio,2))+1)*deviceHeight*deviceWidth);
	stbrPercent = stbr*100;
	
	printf("\n\n==================================================================");
	printf("\n\nThe screen to body ratio is %.2lf percent.", stbrPercent);
	printf("\n\n==================================================================\n\n");
		
	return 0;
}
